#pragma once
//header file guards below
#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include "degree.h"

using namespace std;

class Student {
public:
	//Setters or Mutators
	void SetStudID(string studIden);
	void SetFName(string firstName);
	void SetLName(string lastName);
	void SetEmailAddr(string email);
	void SetAge(int ageNum);
	void SetDaysCompCrs(int* daysCompCrs); // creates daysToCompleteCourse array.
	void SetDaysCompCrsString(int* daysToCompleteCourse);
	void SetDegrProg(DegreeProgram degrProg);

	//Getters or Accessors
	string GetStudID() const;
	string GetFName() const;
	string GetLName() const;
	string GetEmailAddr() const;
	int    GetAge() const;
	int*   GetDaysToCompCrs();
	string GetDaysCompCrsString();
	DegreeProgram GetDegrProg() const;
	string GetDegrProgString() const;

	Student();  //Constructor
	void Print(Student studentData);


private:  //my Student class is like his struct Soldier
	string studentID;
	string firstName;
	string lastName;
	string emailAddress;
	int	   age;
	string days;
	int    daysToCompleteCourse[3];  //Array
	DegreeProgram degreeProgram;
};

#endif