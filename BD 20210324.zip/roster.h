#pragma once
//header file guards below
#ifndef ROSTER_H
#define ROSTER_H

#include <string>
#include "student.h"

using namespace std;

class Roster {
public:
	void add(int index, string studentID, string firstName, string lastName, string emailAddress, int age, int daysToCompleteCourse[], DegreeProgram degreeProgram);
	void remove(string studentID);
	void printAll();  //used to print all students in classRosterArray
	void printAverageDaysInCourse(string studentID);
	void printInvalidEmails();
	void printByDegreeProgram(DegreeProgram degreeProgram);


private:
	string studentID;
	string firstName;
	string lastName;
	string emailAddress;
	int age = 0;
	int daysToCompleteCourse[3] = { 0,0,0 };  //another array within the studentData[]
	DegreeProgram degreeProgram;
};

#endif