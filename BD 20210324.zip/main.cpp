#include <iostream>
#include <string>
#include "roster.h"

using namespace std;

Student parse(string studentData, Roster classRoster) {

	Student student;
	size_t rhs = studentData.find(",");
	student.SetStudID(studentData.substr(0, rhs)); // good syntax, position of 1st character to be copied as a string is 0, it spans up to rhs aka the comma of the string
	string studentID = studentData.substr(0, rhs);

	size_t lhs = rhs + 1;
	rhs = studentData.find(",", lhs);
	student.SetFName(studentData.substr(lhs, rhs - lhs));
	string firstName = studentData.substr(lhs, rhs - lhs);

	lhs = rhs + 1;
	rhs = studentData.find(",", lhs);
	student.SetLName(studentData.substr(lhs, rhs - lhs));
	string lastName = studentData.substr(lhs, rhs - lhs);

	lhs = rhs + 1;
	rhs = studentData.find(",", lhs);
	student.SetEmailAddr(studentData.substr(lhs, rhs - lhs));
	string emailAddress = studentData.substr(lhs, rhs - lhs);

	lhs = rhs + 1;
	rhs = studentData.find(",", lhs);
	student.SetAge(stoi(studentData.substr(lhs, rhs - lhs)));
	int age = stoi(studentData.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = studentData.find(",", lhs);
	int day1 = stoi(studentData.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = studentData.find(",", lhs);
	int day2 = stoi(studentData.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = studentData.find(",", lhs);
	int day3 = stoi(studentData.substr(lhs, rhs - lhs));

	int temp[] = { day1, day2, day3 };  //creates temporary array for the 3 values of days to complete the course
	student.SetDaysCompCrs(temp);

	lhs = rhs + 1;
	rhs = studentData.find(",", lhs);
	string dp = studentData.substr(lhs, rhs - lhs);

	if (dp == "SOFTWARE") {
		student.SetDegrProg(DegreeProgram::SOFTWARE);
	}

	if (dp == "NETWORK") {
		student.SetDegrProg(DegreeProgram::NETWORK);
	}

	if (dp == "SECURITY") {
		student.SetDegrProg(DegreeProgram::SECURITY);
	}

	return student;
}

int main() {
	cout << "C867 - Scripting and Programming Applications, " << "C++, " << "Student ID: 001478703, " << "Brandon Dewell" << endl;

	Roster classRoster;  //creates object named classRoster in the Roster class.


	const string studentData[5] = {
		"A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
		"A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
		"A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
		"A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
		"A5,Brandon,Dewell,bdewel2@wgu.edu,41,30,42,47,SOFTWARE"
	};

	for (int i = 0; i < 5; i++) {
		Student s = parse(studentData[i], classRoster);
		classRoster.add(i, s.GetStudID(), s.GetFName(), s.GetLName(), s.GetEmailAddr(), s.GetAge(), s.GetDaysToCompCrs(), s.GetDegrProg());
	}

	classRoster.printAll();

	//classRoster.printInvalidEmails();

	//classRoster.printAverageDaysInCourse();

	//classRoster.printByDegreeProgram();

	//classRoster.remove();

	//classRoster.printAll();

	return 0;
}