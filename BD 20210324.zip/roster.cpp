#include <iostream>
#include <string>
#include "roster.h"
#include "student.h"

using namespace std;

Student* classRosterArray[5];  //array of 5 pointers that points to objects of type Student

Student A1;
Student A2;
Student A3;
Student A4;
Student A5;

void Roster::add(int index, string studentID, string firstName, string lastName, string emailAddress, int age, int daysToCompleteCourse[], DegreeProgram degreeProgram) {
	classRosterArray[index] = new Student;
	classRosterArray[index]->SetStudID(studentID);
	classRosterArray[index]->SetFName(firstName);
	classRosterArray[index]->SetLName(lastName);
	classRosterArray[index]->SetEmailAddr(emailAddress);
	classRosterArray[index]->SetAge(age);
	classRosterArray[index]->SetDaysCompCrs(daysToCompleteCourse);
	classRosterArray[index]->SetDegrProg(degreeProgram);
}

void Roster::remove(string studentID) {

}

void Roster::printAll() {
	for (int i = 0; i < 5; i++) {
		Student student;
		student.Print(*classRosterArray[i]);
	}

	return;
}

void Roster::printAverageDaysInCourse(string studentID) {
	// this may have a parameter of daysToCompleteCourse instead of studentID
}

void Roster::printInvalidEmails() {

}

void Roster::printByDegreeProgram(DegreeProgram degreeProgram) {

}