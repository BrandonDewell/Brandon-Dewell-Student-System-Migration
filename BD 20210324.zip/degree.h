#pragma once
//header file guards below
#ifndef DEGREE_H
#define DEGREE_H

#include <iostream>
#include <string>

using namespace std;

enum class DegreeProgram {SECURITY, NETWORK, SOFTWARE};
const string degrProgStrings[3] = { "SECURITY", "NETWORK", "SOFTWARE" };  //const makes the array static?

#endif