#include <iostream>
#include <string>
#include "student.h"

using namespace std;

void Student::SetStudID(string studIden) {
	studentID = studIden;
}

void Student::SetFName(string fName) {
	firstName = fName;
}

void Student::SetLName(string lName) {
	lastName = lName;
}

void Student::SetEmailAddr(string email) {
	emailAddress = email;
}

void Student::SetAge(int ageNum) {
	age = ageNum;
}

void Student::SetDaysCompCrs(int* daysCompCrs) {  //Refer to array as pointer no need to give size of array. 
	for (int i = 0; i < 3; i++) { //Pointers to arrays are declared/defined without brackets, they use the first item in the array as the pointer.
		daysToCompleteCourse[i] = daysCompCrs[i];
	}
}

void Student::SetDaysCompCrsString(int* daysToCompleteCourse) {
	string days = "{";
	for (int i = 0; i < 3; i++) {
		days += to_string(daysToCompleteCourse[i]);  //to_string converts an int to a string.
		if (i != 2) {
			days += ", ";  //puts comma after strings on 1st and 2nd string only.
		}
		else {
			days += "}";  //last string does not have comma at end, only }.
		}
	}
	
}

void Student::SetDegrProg(DegreeProgram degrProg) {
	degreeProgram = degrProg;
}

string Student::GetStudID() const {
	return studentID;
}

string Student::GetFName() const {
	return firstName;
}

string Student::GetLName() const {
	return lastName;
}

string Student::GetEmailAddr() const {
	return emailAddress;
}

int Student::GetAge() const {
	return age;
}

int* Student::GetDaysToCompCrs() {
	return daysToCompleteCourse;
}

string Student::GetDaysCompCrsString() {
	return days;
}

DegreeProgram Student::GetDegrProg() const {
	return degreeProgram;
}

string Student::GetDegrProgString() const {
	return degrProgStrings[(int)degreeProgram];  //casts class type DegreeProgram's object degreeProgram as an int and uses it as a parameter
												 //to return as a string in the array degrProgStrings.
}

Student::Student() {  //Student class constructor.
	this->studentID = "none";
	this->lastName = "none";
	this->firstName = "none";
	this->emailAddress = "none";
	this->age = 0;
	this->daysToCompleteCourse[3];
	this->degreeProgram;
	return;
}

void Student::Print(Student studentData) {
	cout << studentData.GetStudID() << "\t First Name:  " << studentData.GetFName() << "\t Last Name:  " << studentData.GetLName() << "\t Age:  " << studentData.GetAge();
	cout << "\t daysInCourse:  " << studentData.GetDaysCompCrsString() << "\t Degree Program:  " << studentData.GetDegrProgString() << endl;
}